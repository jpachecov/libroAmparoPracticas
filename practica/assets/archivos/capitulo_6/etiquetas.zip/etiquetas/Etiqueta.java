/**
 * Clase para ....
 * @see
 * @see
 * @author ...
 * @version ...
 */

public class Etiqueta {
    // Definir aqui los atributos


    /**
     * Constructor que recibe toda la informacion
     * @param para -- cadena con el nombre del destinatario
     * @param de -- cadena con el nombre del remitente
     * @param envio -- fecha de envio
     * @param deDonde -- direccion del remitente
     * @param paraDonde -- direccion del destinatario
     * @param peso -- peso del paquete
     */
    public Etiqueta (String para, String de, Fecha envio, Direccion deDonde,
		     Direccion paraDonde, double peso) {

    }

    //Definir aqui los m�todos para asignar valor a los atributos


    //Definir aqui los m�todos para obtener el valor de los atributos


    //Definir aqui el metodo para generar la etiqueta
}
