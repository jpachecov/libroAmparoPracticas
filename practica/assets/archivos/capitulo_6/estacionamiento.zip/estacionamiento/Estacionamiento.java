import java.util.Scanner;

/**
 * Clase para simular el cobro estacionamiento a autos.
 * @author 
 */
public class Estacionamiento {

    public Estacionamiento() {

        // Escribe aqui el codigo que complete este metodo

    }

    public BoletoEstacionamiento recibirCoche(Hora hora){

        // Escribe aqui el codigo que complete este metodo

    }
    
    public void cobrarCuota(BoletoEstacionamiento boletoDelCliente, Hora hora){

        // Escribe aqui el codigo que complete este metodo

    }
    
    public void despacharCoche(BoletoEstacionamiento boletoDelCliente, Hora hora){

        // Escribe aqui el codigo que complete este metodo
        
    }
}
