/**
  * Clase que permite conocer el valor de algunas variables
  * @author ...
  * @version ...
  */
public class Conocer {
    public void Static main(string[] pps){
    int resultado1;
    double resultado2;

    resultado1 = 46/9;
    resultado1 = 46 % 9 + 4 * 4 - 2;
    resultado1 = 45 + 43 % 5 * (23 * 3 % 2);
    resultado2 = 4 + resultado2 * resultado2 + 4; 
    resultado2 += 1.5 * 3 + (++ resultado1);
    resultado2 -=  1.5 * 3 + resultado1++;


    System.out.println("\t***Conocer el valor de resultado1 y resultado2***\n");
    ...
	}
}

