public class convertidor Temperatura {
	public void Static main(string[] mio){
		double celsius ;
		doublefarenheit = 70.5;
		System.out.println(***Convertidor grados Celsius***);
		System.out.println("Los grados "Farenheit" que voy a convertir son:");
		System.out.println(farenheit + " grados
		                     farenheit");

		celsius = (5/9)*(farenheit - 32);

		System.out.println("Los grados celsius resultantes son:");
		System.out.println(celsius + " grados
		                                celsius");
	}
}

