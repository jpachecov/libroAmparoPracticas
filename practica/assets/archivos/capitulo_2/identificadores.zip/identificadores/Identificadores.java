public class Identificadores {
public static void main(String pps) {
  double pi = 3.1416; 
  int redio = 15;
  double area = p1 * (radio * radio);
  String Mensaje = "Resultado = ";
  System.out.println(mensaje+area);
}

