public class AsignacionCompuesta {
    public static void main (String[] pps) {
	int a = 5;
	int b = 2;
	int c = 3;
	int x = 0;

	x = x + (3 * c);
	System.out.println("El valor de x es " + x);
	x = -b + x+ 87;
	System.out.println("El valor de x es " + x);
	x = x + c + a;
	System.out.println("El valor de x es " + x);
	x = (c + 40) * x;
	System.out.println("El valor de x es " + x);
	x = x / (c + 54);
	System.out.println("El valor de x es " + x);
    }
}
