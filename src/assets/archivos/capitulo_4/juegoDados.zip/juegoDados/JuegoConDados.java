/**
 *  Esta clase se contiene un programa para jugar dadoa con  la computadora
 *  @author Amparo Lopez Gaona
 */
import java.util.Scanner;
public class JuegoConDados {
    
    public static void main(String args[]) {
        
        /*
         *  Aqui, crea los objetos necesarios y usa los metodos
         *  adecuados para resolver tu problema.
         */
        //Pedir nombre del jugador

        // El jugador Lanza los dados

        // Calcular la suma de los dados

        // Si es necesario volver a lanzar los dados

        // Determinar si el jugador gana o pierde

    }
}

