/**
 * Clase para manejar cuentas de debito
 * @author 
 * @version
 */
public class Cuenta {
    //Atributos

    // Crea una cuenta con disponible m�nimo de $2500
    Cuenta(long nCta, double disponibleInicial) {

    }


    // Retira una cantidad de dinero en la cuenta 
    public void retirar(double monto) { 

    }

    // Deposita una cantidad de dinero en la cuenta 
    public void depositar(double monto) {
 
    }
	// Devuelve el disponible de la cuenta
  public double obtenerDisponible() {

  }

    // Devuelve el n�mero de identificaci�n de la cuenta bancaria
    public long obtenerNumCuenta() {

    } 
}

