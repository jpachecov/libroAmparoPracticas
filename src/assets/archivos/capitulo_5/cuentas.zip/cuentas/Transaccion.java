/**
 * ....
 * @author ....
 * @version ...
 */
public class Transaccion {
    public static void main(String[] pps) {
	//Declara las dos cuentas y demas variables

	//Toma dinero de una cuenta

	//Deposita en la otra cuenta

	// Muestra el saldo en ambas cuentas
    }
}
