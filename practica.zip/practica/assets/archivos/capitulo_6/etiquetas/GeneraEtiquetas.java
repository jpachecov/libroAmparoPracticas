public class GeneraEtiquetas{
    static Direccion dir, dir2;
    static Etiqueta etiq;

    public static void generarEtiqueta(...) {

    }

    public static double calcularPrecio(double peso) {

    }

    public static void main(String [] pps) {

	// Solicitar datos para la etiqueta


	// Generar etiqueta


	//Mostrar informaci�n del remitente

	//Calcular y mostrar precio del paquete

    }
}
