public class Formula {
    public static void main(String[] pps) {
	double resultado = 0;
	double r = 6.0;
	int a = 2;
	int b = 3;
	int c = 4;
	int d = 5;

	// Escribir la f�rmula

	System.out.println("Con a = " );  //Completar el mensaje
	System.out.println("El resultado de la formula es "+resultado");
    }
}
