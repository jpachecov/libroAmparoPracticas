/**
  * Clase para calcular el �rea y volumen de un cilindro
  * @author 
  * @version
  */
public class Cilindro {
    public  void  static Main(String[] pps){
	double pi = Math.PI;
		//Define aqui las variables necesarias

	// Calcular el volumne y el area

		//Completar las siguientes lineas 
	System.out.println("\t***Area y volumen de un cilindro***\n");

	System.out.println("El area del cilindro es:");
	System.out.println("El volumen del cilindro es:");
    }
}

