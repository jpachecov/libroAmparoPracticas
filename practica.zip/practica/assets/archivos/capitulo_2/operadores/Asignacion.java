public class Adicional {
    public static void main(String[] pps) {
	int a = 5;
	int b = 2;
	int c = 3;
	int resultado = 0;

	resultado = a + b+ c+ a * b + c;
	resultado = (a + b ) * c;
	resultado = (a + b * c);
    }
}
