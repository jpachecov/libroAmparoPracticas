public class Operadores {
    public static void main(String[] pps) {
	int divisor = 5, dividendoEntero = 39;
	double dividendoReal = 39.0;

	System.out.println("dividendoEntero / divisor = "+ dividendoEntero / divisor);
	System.out.println("dividendoReal / divisor = "+dividendoReal / divisor);
	System.out.println("dividendoEntero % divisor = "+ dividendoEntero % divisor);
	System.out.println("dividendoReal % divisor = "+ dividendoReal % divisor);
    }
}
