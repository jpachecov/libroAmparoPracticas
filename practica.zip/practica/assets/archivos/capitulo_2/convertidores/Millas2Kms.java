public class Millas2Kms {
    public static void main(String[] pps) {
	// Variable real real llamada millas
	// Constante real llamada MILLAS_A_KILOMETROS
	// Variable real llamada kilometros

	// Asignacion de valor a la variable kilometros
	System.out.println("\t\t***Convertidor millas a kilometros***\n");

	System.out.println("La distancia de Londres a Liverpool es de " ... ); //Completar esta linea
    }
}
