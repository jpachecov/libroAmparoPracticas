/**
 * Clase para practicar el paso de parametros al metodo main
 * @author ...
 * @version ...
 */
public class PruebaParametrosMain {
    public static void main (String[] pps) {

	// Verificr que haya cuatro parametros

	//Tomar cada parametro y convertirlo a n�mero 

	//Crear los dos puntos necesarios

	//Calcular e imprimir la distancia que hay entre  los dos puntos
    }
}
