/**
 *  Clase Etiquetador.
 *  Esta clase se encarga de...
 *  @author ...
 */
public class Etiquetador {
    public static void main(String ppss[]){
        
        /*
         *  Agregar aqui el codigo para desplegar la etiqueta
         *  del sobre en pantalla.         
         */       
        System.out.println("Mr. James Bond");        
                
    }    
    
}
