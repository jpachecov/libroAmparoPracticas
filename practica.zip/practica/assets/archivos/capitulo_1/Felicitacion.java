/**
 * Programa para que envie un mensaje de felicitacion al programador
 * @author  ...
 * @version ...
 */
public class Felicitacion {     
  public static void main (String[] pps) {

    ...
  }
}                             
