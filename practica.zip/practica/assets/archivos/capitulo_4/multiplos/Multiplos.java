import java.util.Scanner;

/**
 * Programa para ...
 * @author ....
 * @version .... Aqui pon la fecha
 */
public class Multiplos {
    public static void main(String[] pps) {
	Dado dadito =  	// Declarar las variables incluyendo un dado
	int producto1 = 
	int producto2 = 


	// Pedir al usuario su nombre 

	// Pedir al usuario que tire su dado (s�lo debe dar ENTER)

	// Pedir al usuario que tire otra vez su dado (s�lo debe dar ENTER)

	// Calcular su producto

	// Hacer la computadora tire dos veces su dado y calcular su producto

	//Determinar si el producto del jugador es multiplo de 3, de 5 pero no de ambos

	//Determinar si el producto de la computadora es multiplo de 3, de 5 pero no de ambos

	// Si ning�n producto hace ganador a ningun jugador,
	// volver a tirar un dado cada uno.

	//Determinar el ganador

    }
}
