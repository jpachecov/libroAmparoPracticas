/**
 *  Clase HoraMundo.
 *  Esta clase se encarga de desplegar en pantalla
 *  la hora de 3 ciudades diferentes.
 *  @author Escribe tu nombre aqui
 */
public class HoraMundo {
    
    public static void main(String args[]) {
        
        /*
         *  Aqui, crea los objetos necesarios y usa los metodos
         *  adecuados para resolver tu problema.
         */
        
    }
    
}