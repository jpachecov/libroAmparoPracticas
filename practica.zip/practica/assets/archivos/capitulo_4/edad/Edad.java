import java.util.Scanner;
/**
 * Programa para calcular la edad de una persona
 * Objetivo. crear y utilizar objetos de la clase Fecha
 * @author 
 * @version
 */ 
public class Edad {
    public static void main(String[] pps) {
	Scanner in = new Scanner(System.in);

	//Declarar las variables

	System.out.print("Dame tu nombre ");
	String nombre = in.nextLine();

	//Recabar informacion


	//Validar la informacion	

	//Calcular edad

	//Calcular cantidad de dias para el proximo cumpleanos

	//Calcular en que rango de edad esta
    }
}
