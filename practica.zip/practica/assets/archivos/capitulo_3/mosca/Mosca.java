/**
 * Programa para trabajar con metodos de la clase String
 * @author  ...
 * @version ...
 */
public class Mosca {
  public static void main (String [] pps) {
    String frase = new String ("Una mosca parada en la pared, en la pared      ");
    String frase1, frase2, frase3, frase4, frase5;
  
    System.out.println("Cadena original: \"" + frase + "\"");
    System.out.println("Longitud de la cadena: " + ...);  //Contar caracteres de la cadena

    frase1 = ... ;  // Eliminar los blancos al final de la frase
    System.out.print("La cadena \"" + frase1 + "\"");

                    //Contar caracteres de la nueva cadena
    System.out.println(" tiene " + ... + " caracteres ");  

    frase2 = ... ;  //Poner la frase1 en may�sculas
    frase3 = ... ;  // Sustituir las vocales por I's en frase2
    frase4 = ... ;  // Sustituir las I'es por U's en frase3
    frase5 = ... ;  // Sustituir mosca por MOSCOTA en frase1
    frase6 = ... ;  // Agregar la frase1 PINTADA DE ROJO
    

    // Imprimir cada "mutaci�n" de la cadena
    System.out.println("Frase #1: " + frase1);
    System.out.println("Frase #2: " + frase2);
    System.out.println("Frase #3: " + frase3);
    System.out.println("Frase #4: " + frase4);
    System.out.println("Frase #4: " + frase5);
    System.out.println("Frase #4: " + frase6);
  }
}
