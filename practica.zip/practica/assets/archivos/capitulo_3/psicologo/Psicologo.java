import java.util.Scanner;
/**
 * Programa para tener sesiones con un psicologo
 * @author 
 * @version
 */
public class Psicologo {
    public static void main(String [] pps) {
	//Declarar variables
    // Dar bienvenida al paciente y solicitar su nombre

    //Saludar al paciente y preguntar cu�l es su problema.

    //Contestar "MMMM... ya veo", en otra l�nea "Y dime...Por qu� dices ...

    //Contestar Muy interesante!!, Hablaremos de ello con  m�s detalle en la siguiente sesi�n.

    }
}
