/**
 * Programa para generar mensajes Telegr�ficos
 * Objetivo: Utilizar objetos de la clase String
 *@author 
 *@version 
 */
   
public class Telegrafo {
	public static void main (String [] args) {
		
		//Define aqu� las referencias a objetos que necesites
		//Define aqu� las variables que necesites
		
		//Recaba informacion
		
	    System.out.println ("\n\t\t***Telegrama***");
		
		//Coloca el c�digo faltante
		
		
	}
}
